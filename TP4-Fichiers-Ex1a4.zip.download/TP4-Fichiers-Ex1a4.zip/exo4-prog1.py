# TP 4
# Exercice 4
# Programme 1
def incremente (a):
    a = a+1

# prog. principal
if __name__=="__main__":
    b=3
    incremente(b)
    print (b)
    a=5
    incremente(a)
    print (a)
